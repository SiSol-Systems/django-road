from django.apps import AppConfig


class RoadConfig(AppConfig):
    name = 'django_road'
